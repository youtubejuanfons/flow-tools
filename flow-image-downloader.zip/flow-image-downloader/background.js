// Flow Image Downloader - service worker
//   1. Toggle the in-page panel when the toolbar icon is clicked.
//   2. Act as a fetch proxy when the page itself is blocked by CORS,
//      and as a download fallback when the folder picker is not available.
//   3. Check whether a newer version has been published.

// ===========================================================================
//  UPDATE CHECK  -  change this URL to your own
// ===========================================================================
//  Chrome does not auto-update extensions loaded with "Load unpacked", so the
//  extension asks a file you control whether a newer version exists, and shows
//  a notice in the panel plus a badge on the toolbar icon.
//
//  Publish a file at the URL below containing exactly this:
//
//      {
//        "version": "1.9.0",
//        "notes": "What changed in one short line",
//        "download": "https://optional-link-to-the-zip"
//      }
//
//  Raise "version" whenever you send out a new build. Anyone running an older
//  one sees the notice within a few hours, or immediately if they restart
//  Chrome. If the URL is unreachable the check fails silently.
// ===========================================================================

const UPDATE_MANIFEST_URL =
  'https://raw.githubusercontent.com/youtubejuanfons/flow-tools/main/flow-image-downloader.json';

const CHECK_EVERY_HOURS = 6;

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'FID_TOGGLE_PANEL' });
  } catch (e) {
    // Content script not injected yet (e.g. extension was just reloaded).
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    } catch (err) {
      console.warn('[Flow Image Downloader] Could not open the panel on this tab:', err);
    }
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'FID_FETCH') {
    fetchAsDataUrl(msg.url)
      .then((payload) => sendResponse({ ok: true, ...payload }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true; // keep the message channel open for the async response
  }

  if (msg && msg.type === 'FID_DOWNLOAD') {
    chrome.downloads.download(
      {
        url: msg.url,
        filename: msg.filename,
        conflictAction: 'uniquify',
        saveAs: false
      },
      (id) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ ok: true, id });
        }
      }
    );
    return true;
  }
});

async function fetchAsDataUrl(url) {
  const res = await fetch(url, { credentials: 'omit' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const blob = await res.blob();
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
  return { dataUrl, mime: blob.type, size: blob.size };
}


// ----------------------------------------------------------- update check

// Compares dotted version numbers: 1.10.0 is newer than 1.9.0.
function isNewer(candidate, current) {
  const a = String(candidate).split('.').map((n) => parseInt(n, 10) || 0);
  const b = String(current).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0;
    const y = b[i] || 0;
    if (x > y) return true;
    if (x < y) return false;
  }
  return false;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;

  if (/CHANGE-ME/.test(UPDATE_MANIFEST_URL)) return; // not configured yet

  let data;
  try {
    const res = await fetch(UPDATE_MANIFEST_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    data = await res.json();
  } catch (e) {
    return; // offline, URL moved, malformed file: stay quiet
  }

  if (!data || !data.version) return;

  const available = isNewer(data.version, current);

  await chrome.storage.local.set({
    fidUpdate: available
      ? {
          version: String(data.version),
          notes: data.notes ? String(data.notes).slice(0, 200) : '',
          download: typeof data.download === 'string' ? data.download : '',
          current: current
        }
      : null
  });

  try {
    await chrome.action.setBadgeText({ text: available ? 'NEW' : '' });
    if (available) await chrome.action.setBadgeBackgroundColor({ color: '#E5A50A' });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('fid-update-check', { delayInMinutes: 1, periodInMinutes: CHECK_EVERY_HOURS * 60 });
  checkForUpdate();
});

chrome.runtime.onStartup.addListener(() => {
  checkForUpdate();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fid-update-check') checkForUpdate();
});
