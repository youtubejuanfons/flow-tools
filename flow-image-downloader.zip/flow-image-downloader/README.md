# Flow Image Downloader — v1.9

Downloads every image of a Google Flow project **in order**, renamed `001`,
`002`, `003`…, at the largest resolution the CDN serves, into a folder of your
choice. Nothing else: no filters, no watermarks, no accounts.

---

## 1. Install (one time)

1. Unzip the folder somewhere permanent, e.g. `Documents/flow-image-downloader`.
   Chrome loads the extension from that folder every time it starts, so do not
   delete it afterwards.
2. Open `chrome://extensions`.
3. Top right: turn on **Developer mode**.
4. Top left: **Load unpacked** → select the folder containing `manifest.json`.
5. Pin the extension from the puzzle-piece icon so it is always visible.

**Upgrading from v1.0:** go to `chrome://extensions`, click the circular reload
arrow on the extension card, then reload your Flow tab.

## 2. Use it

There are now two ways in, so it can never become unreachable:

- the blue **Images** pill in the top right corner of the Flow page, or
- the toolbar icon.

Both open the same panel. You can drag it by its header.

1. Open the Flow project.
2. **Scroll through the project once, top to bottom.** The extension captures
   images the moment they appear on screen, so manual scrolling is the most
   reliable way. The counter at the top of the panel goes up as it captures.
   The **Auto-scroll the project** button does the same thing automatically —
   use it if you prefer, and **Stop** interrupts it at any point.
3. The numbering is handled for you: Flow lists the newest generation at the
   top, so the extension flips the list and `001` is always the first image you
   generated. There is nothing to configure.
4. Check the numbered thumbnails in the panel — that is exactly the order the
   files will be saved in. Click any thumbnail to open it full size and confirm
   `001` really is the first prompt.
5. Fill in **Folder name** (e.g. `video-034`), optional **Prefix**, and
   **Start at**. Leave **Save as** on **PNG** unless you have a reason not to:
   Google's CDN serves WebP, which Premiere and After Effects cannot open, so
   the extension re-encodes each file after downloading it.
   **Min size px** is the filter that keeps interface graphics out of the batch.
   400 is right for 16:9 generations; lower it only if real images are being
   skipped.
6. **Browse…** to pick where on your computer that folder goes. Remembered for
   next time. Skip it and everything lands in Downloads instead.
7. **Download in order.**

Result:

```
<folder you chose>/
└── video-034/
    ├── 001.png
    ├── 002.png
    └── …
```

## Which pages it runs on

Flow moved from `labs.google/fx/tools/flow` to `flow.google.com`, where a
project lives at `/project/<id>`. Both domains are declared in the manifest.
The extension only captures inside a project page — everywhere else is the
gallery, whose covers belong to other videos. If Flow changes domain again,
add the new one to `content_scripts.matches` and `host_permissions` in
`manifest.json`, and check `isGallery()` in `content.js`.

## Update notices

Chrome does not auto-update extensions loaded with "Load unpacked", so the
extension checks a file you publish and shows a notice when you release a newer
build.

1. Put `flow-image-downloader.json` somewhere with a public raw URL — a GitHub
   Gist or a file in a repo is the easiest. It contains:

   ```json
   {
     "version": "1.9.0",
     "notes": "What changed, one short line",
     "download": ""
     }
   ```

2. Open `background.js` and set `UPDATE_MANIFEST_URL` to that raw URL. While it
   still says `CHANGE-ME` the check does nothing.
3. If you host it somewhere other than GitHub, add that host to
   `host_permissions` in `manifest.json`.

From then on: every time you send out a new build, raise `version` in both
`manifest.json` and the published JSON. Anyone on an older build gets a NEW
badge on the toolbar icon and an orange banner at the top of the panel telling
them which version they are on and what to do. The check runs on startup and
every 6 hours, and fails silently if the URL is unreachable.

## How the order is worked out

Flow's grid is virtualised: React recycles the `<img>` nodes and positions them
with transforms, so the order of the nodes in the DOM bears no relation to the
order you see on screen. Reading `querySelectorAll('img')` returned a shuffled
list, which is why the numbering came out scrambled.

Every captured image now stores the position it occupies in the page, measured
with `getBoundingClientRect` plus the scroll offset of its scroll container, so
transforms are already accounted for. At download time the list is sorted the
way a human reads the grid — rows top to bottom, left to right within each row,
with a row tolerance of half a thumbnail height — and then reversed, because
Flow puts the newest generation at the top left.

Images that never reported a size (still loading when last seen) cannot be
placed. They go at the very end so they never shift the numbering of the rest,
and the panel says so instead of failing quietly.

## Missing images

Type the number of prompts you sent into **How many prompts did you send?**.
The counter then reads `70 / 100` and turns amber until it matches, and the
download is blocked while any are missing. Set it to 0 to turn the check off.

Auto-scroll now stops only when the page physically cannot scroll any further.
It used to give up after a few steps that produced no new images, which meant a
long project with a stretch of already-seen thumbnails halfway down stopped at
around half the page. Auto-scroll also makes two passes on purpose. The first triggers the loading, the
second catches whatever had not finished loading when it scrolled past — that
is the usual reason a slower machine captures fewer images than a fast one.

## Projects never mix

Flow is a single-page app, so opening another project does not reload the page.
The extension polls the URL and wipes the captured list the moment the project
changes, and it captures nothing at all while you are on the projects list
screen — those cover thumbnails are images from every other project. The panel
shows which project it is currently capturing from.

## 3. If something looks wrong

**A logo or interface graphic ends up in the batch.** Raise **Min size px**.
Anything below that width or height is ignored, and known interface asset URLs
(logos, icons, avatars, gstatic) are skipped regardless of size.

**Wrong number of images captured.** Press **Clear list**, scroll the project
again from the very top, and watch the counter.

**Checking you got full resolution.** When a batch finishes, the status line
reports the pixel size and original format of the first image, e.g.
`First image: 1376x768, source jpeg`. Compare that against what Flow generated.

**Nothing is captured at all.** Press **Diagnostics** at the bottom of the
panel. It prints what the extension can see on the page: how many `<img>`
elements exist, their sizes, the scroll container it detected, and ten sample
image URLs. Select all the text in that box, copy it, and send it over — that
report is what makes it possible to fix the selectors.

**The panel disappears.** It should not any more: the UI lives in an isolated
shadow root attached to `<html>`, and a watchdog re-attaches it every 1.5
seconds if Flow removes it. If it ever does vanish, the blue **Images** pill
brings it straight back without reloading the page.

**Images download but at preview size.** The URL rewrite in `upgradeUrl()`
(inside `content.js`) is what strips Google's size cap. If Flow changes its CDN
format, the diagnostics report shows the real URLs and the rule can be adapted.

## Privacy

Everything runs locally in the browser. No server, no analytics, no account. It
reads the Flow page you have open and writes files where you tell it to.
