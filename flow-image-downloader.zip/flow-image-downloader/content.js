/* Flow Image Downloader v1.1 — content script
 *
 * What changed vs 1.0 and why:
 *  - The UI now lives in a Shadow DOM host attached to <html>, with a watchdog
 *    that re-attaches it if the page rips it out. In 1.0 React removed the
 *    panel and the extension became unreachable until a page reload.
 *  - Images are collected passively from the moment the page loads (mutation
 *    observer), so the fragile auto-scroll is now optional rather than required.
 *  - Every entry point is wrapped in try/catch and reports to the panel, so a
 *    failure shows a message instead of silently killing the extension.
 *  - Added a diagnostics report so the page structure can be inspected when a
 *    scan comes back wrong.
 */

(() => {
  'use strict';

  // Re-injection (or a second click on the toolbar icon) just toggles.
  if (window.__fidLoaded) {
    if (typeof window.__fidToggle === 'function') window.__fidToggle();
    return;
  }
  window.__fidLoaded = true;

  // ---------------------------------------------------------------- state

  const state = {
    items: [],
    seen: new Map(),
    dirHandle: null,
    busy: false,
    cancel: false,
    rendered: 0,
    scrolling: false
  };

  const settings = {
    prefix: '',
    startAt: 1,
    folderName: 'flow-images',
    minSize: 400,
    format: 'png',
    expected: 0
  };

  /* Flow lists the newest generation at the top of the project, so reading the
   * page from top to bottom yields the batch backwards. The list is therefore
   * always flipped, with no option exposed: 001 is always the first image you
   * generated. If Flow ever switches to oldest-first, set this to false.
   */
  const NEWEST_FIRST = true;

  /* Flow's grid is virtualised: React recycles the <img> nodes and places them
   * with transforms, so the order of the nodes in the DOM has nothing to do
   * with the order you see on screen. Reading document.querySelectorAll('img')
   * therefore produced a shuffled list.
   *
   * Instead, every captured image carries the position it occupies in the page
   * (see absolutePosition), and the list is sorted the way a human reads the
   * grid: top row first, left to right inside each row. Reversing that gives
   * creation order, because Flow puts the newest generation at the top left.
   */
  function ordered() {
    const all = state.items.slice();
    const placed = all.filter((i) => i.pos);
    const unplaced = all.filter((i) => !i.pos);

    // Not enough geometry to trust: fall back to capture order.
    if (placed.length < 2) return NEWEST_FIRST ? all.slice().reverse() : all;

    // Row tolerance from the typical thumbnail height: items in the same row
    // are never aligned to the pixel.
    const heights = placed.map((i) => i.pos.h).filter((h) => h > 0).sort((a, b) => a - b);
    const medianH = heights.length ? heights[Math.floor(heights.length / 2)] : 120;
    const tol = Math.max(16, medianH * 0.5);

    placed.sort((a, b) => a.pos.y - b.pos.y);

    const rows = [];
    let row = [];
    let rowTop = null;
    for (const item of placed) {
      if (rowTop === null) {
        rowTop = item.pos.y;
        row.push(item);
      } else if (item.pos.y - rowTop <= tol) {
        row.push(item);
      } else {
        rows.push(row);
        row = [item];
        rowTop = item.pos.y;
      }
    }
    if (row.length) rows.push(row);

    rows.forEach((r) => r.sort((a, b) => a.pos.x - b.pos.x));

    let out = [];
    rows.forEach((r) => { out = out.concat(r); });
    if (NEWEST_FIRST) out.reverse();

    // Anything with no geometry cannot be placed. It goes at the very end so
    // it never shifts the numbering of the images that were placed correctly.
    return out.concat(unplaced);
  }

  /* Where an image sits in the page, independent of the current scroll.
   * getBoundingClientRect already accounts for the transforms the virtual grid
   * applies, so this is the position you actually see.
   */
  let scrollerCache;

  function findScrollParent(node) {
    let el = node.parentElement;
    let depth = 0;
    while (el && depth < 30) {
      depth++;
      try {
        const st = getComputedStyle(el);
        if (/auto|scroll|overlay/.test(st.overflowY) && el.scrollHeight > el.clientHeight + 4) return el;
      } catch (e) {}
      el = el.parentElement;
    }
    return null;
  }

  function absolutePosition(img) {
    const r = img.getBoundingClientRect();
    if (scrollerCache === undefined) scrollerCache = findScrollParent(img);
    const sp = scrollerCache;
    if (sp && document.documentElement.contains(sp)) {
      const cr = sp.getBoundingClientRect();
      return {
        x: r.left - cr.left + sp.scrollLeft,
        y: r.top - cr.top + sp.scrollTop,
        w: r.width,
        h: r.height
      };
    }
    return {
      x: r.left + (window.scrollX || 0),
      y: r.top + (window.scrollY || 0),
      w: r.width,
      h: r.height
    };
  }

  // UI chrome that lives on the Flow page and must never be captured.
  const JUNK_URL = /gstatic\.com|\/static\/|sprite|favicon|logo|icon|avatar|profile|badge/i;

  const supportsPicker = typeof window.showDirectoryPicker === 'function';

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const pad = (n, w) => String(n).padStart(w, '0');
  const sanitize = (s) => String(s).replace(/[\\/:*?"<>|]+/g, '-').trim();

  function extFromMime(mime) {
    if (!mime) return 'png';
    if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
    if (mime.includes('webp')) return 'webp';
    if (mime.includes('gif')) return 'gif';
    if (mime.includes('avif')) return 'avif';
    return 'png';
  }

  // ------------------------------------------- maximum-resolution rewrite

  /* Returns the URLs to try, best first.
   *
   * Google's image CDN encodes options after "=".  Two matter here:
   *   s0  full size, no cap
   *   d   deliver the stored original instead of a re-encode
   * Without "d" the CDN transcodes to WebP, which is why v1.1 produced .webp
   * files even though the master Flow stores is a JPEG.
   */
  function candidateUrls(rawUrl) {
    const url = rawUrl;
    const out = [];

    if (/googleusercontent\.com|ggpht\.com/.test(url)) {
      const bare = url.replace(/=[-\w]+$/, '');
      out.push(bare + '=s0-d'); // original bytes, original format
      out.push(bare + '=d');
      out.push(bare + '=s0'); // full size, may be re-encoded to WebP
      out.push(url);
      return out;
    }

    // Signed URLs break if any parameter is touched.
    if (/[?&](X-Goog-Signature|Signature|Expires|token|sig)=/i.test(url)) return [url];

    try {
      const u = new URL(url, location.href);
      const drop = ['w', 'h', 'width', 'height', 'size', 's', 'resize', 'fit', 'q', 'quality'];
      let touched = false;
      drop.forEach((k) => {
        if (u.searchParams.has(k)) {
          u.searchParams.delete(k);
          touched = true;
        }
      });
      if (touched) out.push(u.toString());
    } catch (e) {}

    const pathFix = url.replace(/\/[sw]\d{2,4}(?=\/)/, '/s0');
    if (pathFix !== url) out.push(pathFix);
    out.push(url);
    return out;
  }

  function bestUrlFor(img) {
    const cands = [];
    if (img.srcset) {
      img.srcset.split(',').forEach((part) => {
        const bits = part.trim().split(/\s+/);
        if (!bits[0]) return;
        cands.push({ url: bits[0], w: parseInt((bits[1] || '').replace(/\D/g, ''), 10) || 0 });
      });
    }
    ['data-full', 'data-original', 'data-src', 'src'].forEach((a) => {
      const v = img.getAttribute(a);
      if (v) cands.push({ url: v, w: img.naturalWidth || 0 });
    });
    if (!cands.length) return null;
    cands.sort((a, b) => b.w - a.w);
    return cands[0].url;
  }

  function dedupeKey(url) {
    return url
      .replace(/=[-\w]+$/, '')
      .replace(/[?#].*$/, '')
      .replace(/\/[sw]\d{2,4}(?=\/)/, '/');
  }

  // ------------------------------------------------------------ collecting

  // Hosts that have already produced accepted images. Used to rescue thumbnails
  // that are mid-load: an <img> that has not finished loading reports a size of
  // zero, and on a slower machine that is most of the grid while scrolling.
  const acceptedHosts = new Set();

  function isContentImage(img) {
    try {
      if (host && host.contains(img)) return false;
      const src = img.currentSrc || img.src || img.getAttribute('data-src') || '';
      if (!src) return false;
      if (src.startsWith('data:image/svg')) return false;
      if (/\.svg(\?|$)/i.test(src)) return false;
      if (JUNK_URL.test(src)) return false;

      const r = img.getBoundingClientRect();
      const w = Math.max(img.naturalWidth || 0, r.width);
      const h2 = Math.max(img.naturalHeight || 0, r.height);

      // Nothing measurable yet — judge it by where it comes from instead of
      // throwing it away, otherwise slow connections silently lose images.
      if (w === 0 && h2 === 0) {
        try {
          return acceptedHosts.has(new URL(src, location.href).host);
        } catch (e) {
          return false;
        }
      }

      // Measurable and too small: interface graphic, reject it.
      return w >= settings.minSize && h2 >= settings.minSize;
    } catch (e) {
      return false;
    }
  }

  function harvest() {
    let added = 0;
    let imgs;
    try {
      imgs = document.querySelectorAll('img');
    } catch (e) {
      return 0;
    }
    scrollerCache = undefined; // re-detect the scroll container once per sweep
    imgs.forEach((img) => {
      if (!isContentImage(img)) return;
      const best = bestUrlFor(img);
      if (!best) return;
      let abs;
      try {
        abs = new URL(best, location.href).toString();
      } catch (e) {
        return;
      }
      const key = dedupeKey(abs);

      let pos = null;
      try {
        pos = absolutePosition(img);
        if (!(pos.w > 0 && pos.h > 0)) pos = null; // not laid out yet
      } catch (e) {}

      const existing = state.seen.get(key);
      if (existing) {
        // Seen before. Keep the most recent reading: the first one may have
        // been taken mid-layout, before the grid settled.
        if (pos) existing.pos = pos;
        return;
      }

      try {
        acceptedHosts.add(new URL(abs).host);
      } catch (e) {}
      const item = {
        candidates: candidateUrls(abs),
        thumb: img.currentSrc || img.src,
        pos: pos
      };
      state.seen.set(key, item);
      state.items.push(item);
      added++;
    });
    return added;
  }

  // Passive collector: records images as the page loads them, so the user can
  // simply scroll through the project by hand and everything is captured.

  /* Flow is a single-page app: opening another project swaps the content
   * without reloading, so a list started in project A would keep growing in
   * project B. The path is polled and the list is wiped whenever it changes.
   * The projects gallery at the root is skipped entirely, because its cover
   * thumbnails are images from every other project made that day.
   */
  let currentPath = location.pathname;

  /* Flow moved from labs.google/fx/tools/flow to flow.google.com, where a
   * project lives at /project/<uuid>. Capture only inside a project; anything
   * else is the gallery, whose covers belong to other videos.
   */
  function isGallery() {
    const p = location.pathname;
    if (/\/project\/[^/]+/.test(p)) return false;
    return true;
  }

  function resetList(message) {
    state.items = [];
    state.seen = new Map();
    state.rendered = 0;
    if (listEl) listEl.innerHTML = '';
    updateCount();
    if (message) setStatus(message);
  }

  function checkRoute() {
    if (location.pathname === currentPath) return;
    currentPath = location.pathname;
    resetList(
      isGallery()
        ? 'You are on the projects list. Open a project — nothing is captured here.'
        : 'Different project opened — the list was cleared automatically.'
    );
    updateProjectLabel();
  }

  let sweepTimer = null;
  function scheduleSweep() {
    if (sweepTimer) return;
    sweepTimer = setTimeout(() => {
      sweepTimer = null;
      if (isGallery()) return; // never capture other projects' cover thumbnails
      const added = harvest();
      if (added) renderList();
      updateCount();
    }, 500);
  }

  const observer = new MutationObserver(scheduleSweep);
  try {
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['src', 'srcset']
    });
  } catch (e) {}
  setInterval(scheduleSweep, 3000);

  // --------------------------------------------------------- auto-scroll

  function scrollCandidates() {
    const list = [];
    const root = document.scrollingElement || document.documentElement;
    if (root) list.push(root);
    try {
      document.querySelectorAll('div, main, section, ul').forEach((n) => {
        if (n.scrollHeight - n.clientHeight < 200) return;
        const oy = getComputedStyle(n).overflowY;
        if (/auto|scroll|overlay/.test(oy)) list.push(n);
      });
    } catch (e) {}
    list.sort((a, b) => b.scrollHeight - b.clientHeight - (a.scrollHeight - a.clientHeight));
    return list;
  }

  async function autoScroll() {
    state.scrolling = true;
    state.cancel = false;

    const targets = scrollCandidates().slice(0, 3);
    if (!targets.length) {
      setStatus('No scrollable area found. Scroll by hand instead — images are captured as they appear.');
      state.scrolling = false;
      return;
    }

    // Harvest continuously while the page moves. Flow unmounts images as soon
    // as they leave the viewport, so waiting for the debounced sweep loses them.
    const fast = setInterval(() => {
      if (harvest()) renderList();
      updateCount();
    }, 150);

    try {
      // Two passes: the first one triggers the loading, the second one catches
      // whatever had not finished loading when it scrolled past.
      for (let pass = 1; pass <= 2 && !state.cancel; pass++) {
        for (const target of targets) {
          try {
            target.scrollTop = 0;
          } catch (e) {}
        }
        await sleep(900);
        harvest();
        renderList();

        let idle = 0;
        let steps = 0;

        // Only stop when the page physically refuses to move any further AND
        // nothing new turns up. A stretch of already-seen images in the middle
        // of a long project is not a reason to give up scrolling — that is what
        // made it stop halfway.
        while (idle < 6 && steps < 600 && !state.cancel) {
          steps++;
          let moved = false;
          let atBottom = true;

          for (const target of targets) {
            try {
              const before = target.scrollTop;
              const step = Math.max(200, target.clientHeight * 0.45);
              target.scrollTop = before + step;
              if (target.scrollTop > before) moved = true;
              if (target.scrollTop + target.clientHeight < target.scrollHeight - 8) atBottom = false;
            } catch (e) {}
          }

          await sleep(420);
          const added = harvest();
          if (added) renderList();
          updateCount();
          setStatus(`Pass ${pass} of 2 — ${state.items.length} images captured so far.`);

          if (!moved && atBottom && !added) idle++;
          else idle = 0;
        }
      }
    } finally {
      clearInterval(fast);
      harvest();
      renderList();
    }

    state.scrolling = false;
    const noPos = state.items.filter((i) => !i.pos).length;
    if (noPos) {
      setStatus(
        `Done, but ${noPos} of ${state.items.length} images have no position and were put at the end. ` +
          'Press Clear list and run Auto-scroll again before downloading.'
      );
      renderList(true);
      return;
    }
    setStatus(
      state.cancel
        ? `Stopped. ${state.items.length} images captured.`
        : `Done. ${state.items.length} images captured.` +
          (settings.expected && state.items.length < settings.expected
            ? ' That is fewer than the ' + settings.expected + ' you expected — check the Flow chat first.'
            : '')
    );
  }

  // ------------------------------------------------------------ retrieval

  async function fetchOne(url) {
    try {
      const res = await fetch(url, { credentials: 'include' });
      if (res.ok) {
        const blob = await res.blob();
        if (blob.size > 0) return blob;
      }
    } catch (e) {}

    const reply = await chrome.runtime.sendMessage({ type: 'FID_FETCH', url });
    if (!reply || !reply.ok) throw new Error(reply ? reply.error : 'fetch failed');
    const res = await fetch(reply.dataUrl);
    return await res.blob();
  }

  // Walk the candidate list until one returns real image bytes.
  async function getBlob(item) {
    let lastErr = null;
    for (const url of item.candidates) {
      try {
        const blob = await fetchOne(url);
        if (blob && blob.size > 1024 && /^image\//.test(blob.type)) return blob;
      } catch (err) {
        lastErr = err;
      }
    }
    throw lastErr || new Error('no candidate URL returned an image');
  }

  // Re-encode so the files open in any editor. WebP is what Google's CDN
  // hands back by default and Premiere / After Effects cannot read it.
  async function convert(blob, format) {
    if (format === 'original') return blob;
    const type = format === 'jpg' ? 'image/jpeg' : 'image/png';
    if (blob.type === type) return blob;
    const bmp = await createImageBitmap(blob);
    const canvas = new OffscreenCanvas(bmp.width, bmp.height);
    const ctx = canvas.getContext('2d');
    if (type === 'image/jpeg') {
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, bmp.width, bmp.height);
    }
    ctx.drawImage(bmp, 0, 0);
    bmp.close();
    return await canvas.convertToBlob({ type, quality: 0.95 });
  }

  // -------------------------------------------------------------- writing

  async function ensurePermission(handle) {
    const opts = { mode: 'readwrite' };
    if ((await handle.queryPermission(opts)) === 'granted') return true;
    return (await handle.requestPermission(opts)) === 'granted';
  }

  async function downloadAll() {
    if (!state.items.length) {
      setStatus('Nothing captured yet. Scroll through the project, or press Auto-scroll.');
      return;
    }

    if (settings.expected > 0 && state.items.length < settings.expected) {
      setStatus(
        'Only ' + state.items.length + ' of ' + settings.expected +
          ' captured. Check the Flow chat generated them all, then press Auto-scroll again. ' +
          'Set the prompt count to 0 if you really want to download anyway.'
      );
      return;
    }

    state.busy = true;
    state.cancel = false;
    setButtons();

    const items = ordered();
    const total = items.length;
    const width = Math.max(3, String(settings.startAt + total - 1).length);
    const folder = sanitize(settings.folderName) || 'flow-images';

    let target = null;
    let usingPicker = false;

    try {
      if (state.dirHandle) {
        if (!(await ensurePermission(state.dirHandle))) {
          setStatus('Permission for that folder was denied. Choose it again with Browse.');
          state.busy = false;
          setButtons();
          return;
        }
        target = await state.dirHandle.getDirectoryHandle(folder, { create: true });
        usingPicker = true;
      }
    } catch (err) {
      setStatus('Could not open that folder: ' + err.message + ' — using Downloads instead.');
    }

    let done = 0;
    let failed = 0;
    let firstInfo = '';

    for (let i = 0; i < total; i++) {
      if (state.cancel) break;
      const item = items[i];
      const n = settings.startAt + i;

      try {
        const raw = await getBlob(item);
        if (i === 0) {
          try {
            const bmp = await createImageBitmap(raw);
            firstInfo = `${bmp.width}x${bmp.height}, source ${raw.type.replace('image/', '')}`;
            bmp.close();
          } catch (e) {}
        }
        const blob = await convert(raw, settings.format);
        const ext = extFromMime(blob.type);
        const base = settings.prefix ? sanitize(settings.prefix) + '_' : '';
        const filename = `${base}${pad(n, width)}.${ext}`;

        if (usingPicker) {
          const fh = await target.getFileHandle(filename, { create: true });
          const w = await fh.createWritable();
          await w.write(blob);
          await w.close();
        } else {
          const dataUrl = await new Promise((res, rej) => {
            const r = new FileReader();
            r.onload = () => res(r.result);
            r.onerror = () => rej(r.error);
            r.readAsDataURL(blob);
          });
          const reply = await chrome.runtime.sendMessage({
            type: 'FID_DOWNLOAD',
            url: dataUrl,
            filename: `${folder}/${filename}`
          });
          if (!reply || !reply.ok) throw new Error(reply ? reply.error : 'download failed');
        }
        done++;
      } catch (err) {
        failed++;
        console.warn('[FID] image', i + 1, 'failed:', item.candidates[0], err);
      }

      setProgress(i + 1, total, done, failed);
      await sleep(50);
    }

    state.busy = false;
    setButtons();
    const where = usingPicker ? 'the folder you chose' : 'Downloads/' + folder;
    setStatus(
      `${state.cancel ? 'Stopped' : 'Finished'}. ${done} of ${total} saved into ${where}.` +
        (firstInfo ? ' First image: ' + firstInfo + '.' : '') +
        (failed ? ' ' + failed + ' failed.' : '')
    );
  }

  // ---------------------------------------------------- diagnostics report

  function diagnostics() {
    const all = Array.from(document.querySelectorAll('img'));
    const lines = [];
    lines.push('URL: ' + location.href);
    lines.push('Total <img> on page: ' + all.length);
    lines.push('Min size setting: ' + settings.minSize);
    lines.push('Captured so far: ' + state.items.length);

    const buckets = {};
    all.forEach((img) => {
      const r = img.getBoundingClientRect();
      const w = Math.round(Math.max(img.naturalWidth || 0, r.width));
      const key = w < 60 ? '<60' : w < 120 ? '60-119' : w < 300 ? '120-299' : '300+';
      buckets[key] = (buckets[key] || 0) + 1;
    });
    lines.push('Widths: ' + JSON.stringify(buckets));

    const sc = scrollCandidates()[0];
    lines.push(
      'Main scroller: ' +
        (sc ? sc.tagName + '.' + String(sc.className).slice(0, 60) + ' h=' + sc.scrollHeight : 'none')
    );

    lines.push('--- capture order after sorting by screen position ---');
    const ord = ordered();
    lines.push('With geometry: ' + state.items.filter((i) => i.pos).length + ' of ' + state.items.length);
    ord.slice(0, 12).forEach((it, i) => {
      const p = it.pos;
      lines.push(
        '  ' + String(i + 1).padStart(3, '0') + '  ' +
        (p ? 'x=' + Math.round(p.x) + ' y=' + Math.round(p.y) : 'no position') + '  ' +
        (it.thumb || '').slice(-40)
      );
    });

    lines.push('--- sample image sources ---');
    all.slice(0, 10).forEach((img, i) => {
      const r = img.getBoundingClientRect();
      lines.push(
        (i + 1) +
          '. ' +
          Math.round(r.width) +
          'x' +
          Math.round(r.height) +
          '  ' +
          (img.currentSrc || img.src || '').slice(0, 160)
      );
    });
    return lines.join('\n');
  }

  // ------------------------------------------------------------------- UI

  let host, shadow, panel, launcher, listEl, statusEl, barEl, progEl, folderEl, countEl, projectEl, updateEl;

  const CSS = `
  * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; margin:0; }
  .wrap { position: fixed; inset: 0; pointer-events: none; z-index: 2147483647; }
  .launcher { position: absolute; top: 16px; right: 16px; pointer-events: auto;
    background:#3b82f6; color:#fff; border:0; border-radius:999px; padding:9px 14px;
    font-size:12px; font-weight:700; cursor:pointer; box-shadow:0 6px 20px rgba(0,0,0,.4); }
  .panel { position:absolute; top:16px; right:16px; width:318px; max-height:84vh;
    display:none; flex-direction:column; pointer-events:auto; background:#17181c; color:#e7e7ea;
    border:1px solid #33353c; border-radius:12px; box-shadow:0 18px 48px rgba(0,0,0,.55);
    font-size:13px; line-height:1.45; overflow:hidden; }
  .panel.open { display:flex; }
  .head { display:flex; align-items:center; justify-content:space-between; padding:10px 12px;
    background:#202127; border-bottom:1px solid #33353c; cursor:move; user-select:none; }
  .title { font-weight:600; }
  .x { background:none; border:0; color:#9a9aa4; font-size:20px; line-height:1; cursor:pointer; }
  .body { padding:12px; overflow-y:auto; }
  .btn { border:0; border-radius:8px; padding:8px 12px; font-size:13px; font-weight:600; cursor:pointer; }
  .btn:disabled { opacity:.5; cursor:default; }
  .primary { background:#3b82f6; color:#fff; width:100%; }
  .ghost { background:#2a2c33; color:#d6d6dc; border:1px solid #3d3f47; font-weight:500; padding:7px 10px; }
  .update { background:#4a3a10; border:1px solid #e5a50a; border-radius:8px; padding:9px 10px;
    margin-bottom:12px; font-size:12px; color:#ffd77a; line-height:1.4; }
  .update b { display:block; font-size:12px; letter-spacing:.4px; color:#ffc93c; margin-bottom:3px; }
  .update a { color:#ffd77a; }
  .count { margin:10px 0 4px; font-size:20px; font-weight:700; }
  .count.short { color:#e5a50a; }
  .count small { font-size:12px; font-weight:500; color:#8b8c96; display:block; }
  .project { margin:2px 0 8px; font-size:11px; color:#7e8089; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .project.warn { color:#e5a50a; }
  .status { margin:8px 0 12px; color:#a5a6b0; font-size:12px; min-height:32px; }
  .row { margin-bottom:10px; }
  .row label { display:block; font-size:11px; text-transform:uppercase; letter-spacing:.5px; color:#8b8c96; margin-bottom:4px; }
  .row input, .row select { width:100%; background:#101115; border:1px solid #3d3f47; border-radius:7px;
    color:#e7e7ea; padding:7px 9px; font-size:13px; }
  .split { display:flex; gap:8px; } .split > div { flex:1; }
  .folder { display:flex; align-items:center; gap:8px; background:#101115; border:1px solid #3d3f47;
    border-radius:7px; padding:5px 5px 5px 9px; }
  .folder span { flex:1; font-size:12px; color:#c8c9d1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .prog { height:6px; background:#2a2c33; border-radius:99px; overflow:hidden; margin:12px 0 6px; }
  .bar { height:100%; width:0; background:#3b82f6; transition:width .15s; }
  .progtext { margin:0 0 12px; font-size:12px; color:#a5a6b0; min-height:16px; }
  .actions { display:flex; gap:8px; } .actions .primary { flex:1; }
  .list { margin-top:12px; display:grid; grid-template-columns:repeat(3,1fr); gap:5px; max-height:200px; overflow-y:auto; }
  .item { position:relative; border-radius:6px; overflow:hidden; background:#101115; cursor:zoom-in; }
  .item img { width:100%; height:54px; object-fit:cover; display:block; }
  .num { position:absolute; top:3px; left:3px; background:rgba(0,0,0,.75); color:#fff;
    font-size:10px; font-weight:700; padding:1px 5px; border-radius:4px; }
  .tools { display:flex; gap:8px; margin-top:12px; border-top:1px solid #2a2c33; padding-top:10px; }
  .tools .ghost { flex:1; font-size:12px; }
  textarea { width:100%; height:130px; margin-top:8px; background:#101115; color:#c8c9d1;
    border:1px solid #3d3f47; border-radius:7px; font-family:monospace; font-size:11px; padding:8px; display:none; }
  `;

  function buildUI() {
    host = document.createElement('div');
    host.id = 'flow-image-downloader-host';
    shadow = host.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = CSS;
    shadow.appendChild(style);

    const wrap = document.createElement('div');
    wrap.className = 'wrap';
    wrap.innerHTML =
      '<button class="launcher">Images</button>' +
      '<div class="panel">' +
      '<div class="head"><span class="title">Flow Image Downloader</span><button class="x">&times;</button></div>' +
      '<div class="body">' +
      '<div class="update" style="display:none"></div>' +
      '<div class="count">0<small>images captured \u2014 001 is your first generation</small></div>' +
      '<p class="project"></p>' +
      '<p class="status">Scroll through your project once — images are captured automatically. Or press Auto-scroll.</p>' +
      '<button class="btn primary" data-act="autoscroll">Auto-scroll the project</button>' +
      '<div class="row" style="margin-top:12px"><label>Folder name</label><input type="text" data-set="folderName" value="flow-images"></div>' +
      '<div class="row split"><div><label>Prefix (optional)</label><input type="text" data-set="prefix" placeholder="none"></div>' +
      '<div style="max-width:82px"><label>Start at</label><input type="number" data-set="startAt" value="1" min="0"></div></div>' +
      '<div class="row"><label>How many prompts did you send?</label>' +
      '<input type="number" data-set="expected" value="0" min="0" placeholder="0 = do not check"></div>' +
      '<div class="row split"><div><label>Save as</label>' +
      '<select data-set="format"><option value="png">PNG</option><option value="jpg">JPG</option>' +
      '<option value="original">Original</option></select></div>' +
      '<div style="max-width:110px"><label>Min size px</label><input type="number" data-set="minSize" value="400" min="50" step="50"></div></div>' +
      '<div class="row"><label>Save into</label><div class="folder"><span class="fname">Downloads folder</span>' +
      '<button class="btn ghost" data-act="pick">Browse&hellip;</button></div></div>' +
      '<div class="prog"><div class="bar"></div></div><p class="progtext"></p>' +
      '<div class="actions"><button class="btn primary" data-act="download">Download in order</button>' +
      '<button class="btn ghost" data-act="stop">Stop</button></div>' +
      '<div class="list"></div>' +
      '<div class="tools"><button class="btn ghost" data-act="reset">Clear list</button>' +
      '<button class="btn ghost" data-act="diag">Diagnostics</button></div>' +
      '<textarea class="diag" readonly></textarea>' +
      '</div></div>';
    shadow.appendChild(wrap);
    document.documentElement.appendChild(host);

    panel = shadow.querySelector('.panel');
    launcher = shadow.querySelector('.launcher');
    listEl = shadow.querySelector('.list');
    statusEl = shadow.querySelector('.status');
    barEl = shadow.querySelector('.bar');
    progEl = shadow.querySelector('.progtext');
    folderEl = shadow.querySelector('.fname');
    countEl = shadow.querySelector('.count');
    projectEl = shadow.querySelector('.project');
    updateEl = shadow.querySelector('.update');
    refreshUpdateNotice();
    updateProjectLabel();

    launcher.addEventListener('click', toggle);
    shadow.querySelector('.x').addEventListener('click', () => panel.classList.remove('open'));

    const NUMERIC = { startAt: 1, minSize: 400, expected: 0 };
    shadow.querySelectorAll('[data-set]').forEach((inp) => {
      const k = inp.dataset.set;
      if (settings[k] !== undefined && settings[k] !== '') inp.value = settings[k];
      inp.addEventListener('change', () => {
        settings[k] = k in NUMERIC ? parseInt(inp.value, 10) || NUMERIC[k] : inp.value;
        try {
          chrome.storage.local.set({ fidSettings: settings });
        } catch (e) {}
        if (k === 'minSize') resetList('Size filter changed — list cleared. Scroll the project again.');
        renderList(true);
      });
    });

    shadow.addEventListener('click', async (ev) => {
      const thumb = ev.target.closest && ev.target.closest('.item');
      if (thumb && thumb.dataset.thumb) {
        window.open(thumb.dataset.thumb, '_blank', 'noopener');
        return;
      }
      const btn = ev.target.closest && ev.target.closest('[data-act]');
      if (!btn) return;
      try {
        const act = btn.dataset.act;
        if (act === 'autoscroll' && !state.scrolling && !state.busy) await autoScroll();
        if (act === 'stop') {
          state.cancel = true;
          setStatus('Stopping…');
        }
        if (act === 'download' && !state.busy) await downloadAll();
        if (act === 'reset') resetList('List cleared.');
        if (act === 'diag') {
          const ta = shadow.querySelector('.diag');
          ta.style.display = ta.style.display === 'block' ? 'none' : 'block';
          ta.value = diagnostics();
          ta.select();
        }
        if (act === 'pick') {
          if (!supportsPicker) {
            setStatus('This browser cannot pick a folder — saving to Downloads.');
            return;
          }
          state.dirHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
          await idbSet('dir', state.dirHandle);
          folderEl.textContent = state.dirHandle.name;
          setStatus('Folder selected. It is remembered for next time.');
        }
      } catch (err) {
        const name = err && err.name ? err.name : '';
        // Closing or cancelling the folder dialog is not a failure.
        if (name === 'AbortError' || name === 'NotAllowedError') {
          setStatus('Folder selection cancelled. Files will go to your Downloads folder.');
          return;
        }
        const detail = (err && err.message) || name || 'unknown error';
        setStatus('Error: ' + detail);
        console.warn('[FID]', err);
      }
    });

    let drag = null;
    shadow.querySelector('.head').addEventListener('mousedown', (e) => {
      if (e.target.closest('.x')) return;
      const r = panel.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!drag) return;
      panel.style.left = e.clientX - drag.dx + 'px';
      panel.style.top = e.clientY - drag.dy + 'px';
      panel.style.right = 'auto';
    });
    window.addEventListener('mouseup', () => {
      drag = null;
    });
  }

  // The page must never be able to remove the UI permanently.
  function watchdog() {
    if (!host || !document.documentElement.contains(host)) {
      const wasOpen = panel && panel.classList.contains('open');
      buildUI();
      if (wasOpen) panel.classList.add('open');
      renderList(true);
      updateCount();
    }
  }

  function toggle() {
    watchdog();
    panel.classList.toggle('open');
  }
  window.__fidToggle = toggle;

  // Shown when the version file says a newer build has been published.
  function renderUpdateNotice(info) {
    if (!updateEl) return;
    if (!info || !info.version) {
      updateEl.style.display = 'none';
      updateEl.innerHTML = '';
      return;
    }
    const esc = (x) =>
      String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

    const notes = info.notes ? ' ' + esc(info.notes) : '';

    // Only link to somewhere we can actually trust the shape of.
    let link = '';
    if (/^https:\/\//i.test(info.download || '')) {
      link =
        '<br><a href="' + esc(info.download) + '" target="_blank" rel="noopener">' +
        'Download v' + esc(info.version) + '</a>' +
        ' &middot; then replace your extension folder with it and press the reload arrow in chrome://extensions';
    } else {
      link = ' Ask for the new zip, replace the folder, then press the reload arrow in chrome://extensions.';
    }

    updateEl.innerHTML =
      '<b>UPDATE AVAILABLE &mdash; v' + esc(info.version) + '</b>' +
      'You are running v' + esc(info.current) + '.' + notes + link;
    updateEl.style.display = 'block';
  }

  function refreshUpdateNotice() {
    try {
      chrome.storage.local.get('fidUpdate', (st) => {
        if (st && st.fidUpdate) renderUpdateNotice(st.fidUpdate);
      });
    } catch (e) {}
  }

  function updateProjectLabel() {
    if (!projectEl) return;
    if (isGallery()) {
      projectEl.textContent = 'Projects list — open a project to start capturing';
      projectEl.className = 'project warn';
      return;
    }
    const id = location.pathname.split('/').filter(Boolean).pop() || '';
    projectEl.textContent = 'Capturing from project ' + id.slice(0, 24);
    projectEl.className = 'project';
  }

  function setStatus(t) {
    if (statusEl) statusEl.textContent = t;
  }
  function updateCount() {
    if (!countEl) return;
    const n = state.items.length;
    const want = settings.expected;
    if (want > 0) {
      const ok = n >= want;
      countEl.className = ok ? 'count' : 'count short';
      countEl.innerHTML =
        n + ' / ' + want +
        '<small>' +
        (ok
          ? 'all prompts accounted for &mdash; 001 is your first generation'
          : want - n + ' missing &mdash; do not download yet') +
        '</small>';
    } else {
      countEl.className = 'count';
      countEl.innerHTML = n + '<small>images captured &mdash; 001 is your first generation</small>';
    }
  }
  function setButtons() {
    if (!shadow) return;
    shadow.querySelectorAll('[data-act="download"], [data-act="autoscroll"]').forEach((b) => {
      b.disabled = state.busy;
    });
  }
  function setProgress(cur, total, done, failed) {
    if (!barEl) return;
    barEl.style.width = Math.round((cur / total) * 100) + '%';
    progEl.textContent = cur + ' / ' + total + ' — ' + done + ' saved' + (failed ? ', ' + failed + ' failed' : '');
  }

  function renderList(full) {
    if (!listEl) return;
    const items = ordered();
    // The list is always flipped, so it cannot be appended to incrementally.
    listEl.innerHTML = '';
    state.rendered = 0;
    const width = Math.max(3, String(settings.startAt + items.length - 1).length);
    for (let i = state.rendered; i < items.length && i < 300; i++) {
      const d = document.createElement('div');
      d.className = 'item';
      d.dataset.thumb = items[i].thumb;
      d.title = 'Click to open image ' + pad(settings.startAt + i, width) + ' full size';
      const s = document.createElement('span');
      s.className = 'num';
      s.textContent = pad(settings.startAt + i, width);
      const im = document.createElement('img');
      im.src = items[i].thumb;
      im.loading = 'lazy';
      d.appendChild(s);
      d.appendChild(im);
      listEl.appendChild(d);
    }
    state.rendered = Math.min(items.length, 300);
    updateCount();
  }

  // ------------------------------------------------------ IndexedDB helper

  function idb() {
    return new Promise((res, rej) => {
      const rq = indexedDB.open('flow-image-downloader', 1);
      rq.onupgradeneeded = () => rq.result.createObjectStore('kv');
      rq.onsuccess = () => res(rq.result);
      rq.onerror = () => rej(rq.error);
    });
  }
  async function idbSet(k, v) {
    const db = await idb();
    return new Promise((res, rej) => {
      const tx = db.transaction('kv', 'readwrite');
      tx.objectStore('kv').put(v, k);
      tx.oncomplete = res;
      tx.onerror = () => rej(tx.error);
    });
  }
  async function idbGet(k) {
    const db = await idb();
    return new Promise((res, rej) => {
      const tx = db.transaction('kv', 'readonly');
      const rq = tx.objectStore('kv').get(k);
      rq.onsuccess = () => res(rq.result);
      rq.onerror = () => rej(rq.error);
    });
  }

  // ------------------------------------------------------------ bootstrap

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === 'FID_TOGGLE_PANEL') toggle();
    });
  } catch (e) {}

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.fidUpdate) renderUpdateNotice(changes.fidUpdate.newValue);
    });
  } catch (e) {}

  buildUI();
  setInterval(() => {
    watchdog();
    checkRoute();
  }, 1500);
  scheduleSweep();

  (async () => {
    try {
      const st = await chrome.storage.local.get('fidSettings');
      if (st && st.fidSettings) {
        Object.assign(settings, st.fidSettings);
        shadow.querySelectorAll('[data-set]').forEach((i) => {
          if (settings[i.dataset.set] !== undefined) i.value = settings[i.dataset.set];
        });
      }
    } catch (e) {}
    try {
      const h = await idbGet('dir');
      if (h) {
        state.dirHandle = h;
        folderEl.textContent = h.name;
      }
    } catch (e) {}
  })();
})();
